class Data {
  static const profileImage =
      "https://avatar-prod-us-east-2.webexcontent.com/Avtr~V1~1eb65fdf-9643-417f-9974-ad72cae0e10f/V1~1a08968daf428f4f5d1ce0f04de95eb40bf8d6d8cb5a0463a6f858f52e3a9df9~49713ad2dabe4cb2a6f83a05c6d6e4f5";
  static final messageList = [
    // Message(
    //   id: '1',
    //   message: "Hi!",
    //   createdAt: DateTime.now(),
    //   sentBy: '1', // userId of who sends the message
    //   status: MessageStatus.read,
    // ),
    // Message(
    //   id: '2',
    //   message: "Hi!",
    //   createdAt: DateTime.now(),
    //   sentBy: '2',
    //   status: MessageStatus.read,
    // ),
    // Message(
    //   id: '3',
    //   message: "We can meet?I am free",
    //   createdAt: DateTime.now(),
    //   sentBy: '1',
    //   status: MessageStatus.read,
    // ),
    // Message(
    //   id: '4',
    //   message: "Can you write the time and place of the meeting?",
    //   createdAt: DateTime.now(),
    //   sentBy: '1',
    //   status: MessageStatus.read,
    // ),
    // Message(
    //   id: '5',
    //   message: "That's fine",
    //   createdAt: DateTime.now(),
    //   sentBy: '2',
    //   reaction: Reaction(reactions: ['\u{2764}'], reactedUserIds: ['1']),
    //   status: MessageStatus.read,
    // ),
    // Message(
    //   id: '6',
    //   message: "When to go ?",
    //   createdAt: DateTime.now(),
    //   sentBy: '3',
    //   status: MessageStatus.read,
    // ),
    // Message(
    //   id: '7',
    //   message: "I guess Simform will reply",
    //   createdAt: DateTime.now(),
    //   sentBy: '4',
    //   status: MessageStatus.read,
    // ),
    // Message(
    //   id: '8',
    //   message: "Hii",
    //   createdAt: DateTime.now(),
    //   sentBy: '2',
    //   reaction: Reaction(
    //     reactions: ['\u{2764}', '\u{1F44D}', '\u{1F44D}'],
    //     reactedUserIds: ['2', '3', '4'],
    //   ),
    //   status: MessageStatus.read,
    //   replyMessage: const ReplyMessage(
    //     message: "Can you write the time and place of the meeting?",
    //     replyTo: '1',
    //     replyBy: '2',
    //     messageId: '4',
    //   ),
    // ),
    // Message(
    //   id: '9',
    //   message: "Done",
    //   createdAt: DateTime.now(),
    //   sentBy: '1',
    //   status: MessageStatus.read,
    //   reaction: Reaction(
    //     reactions: [
    //       '\u{2764}',
    //       '\u{2764}',
    //       '\u{2764}',
    //     ],
    //     reactedUserIds: ['2', '3', '4'],
    //   ),
    // ),
    // Message(
    //   id: '10',
    //   message: "Thank you!!",
    //   status: MessageStatus.read,
    //   createdAt: DateTime.now(),
    //   sentBy: '1',
    //   reaction: Reaction(
    //     reactions: ['\u{2764}', '\u{2764}', '\u{2764}', '\u{2764}'],
    //     reactedUserIds: ['2', '4', '3', '1'],
    //   ),
    // ),
    // Message(
    //   id: '11',
    //   message: "https://miro.medium.com/max/1000/0*s7of7kWnf9fDg4XM.jpeg",
    //   createdAt: DateTime.now(),
    //   messageType: MessageType.image,
    //   sentBy: '1',
    //   reaction: Reaction(reactions: ['\u{2764}'], reactedUserIds: ['2']),
    //   status: MessageStatus.read,
    // ),
    // Message(
    //   id: '12',
    //   message: "🤩🤩",
    //   createdAt: DateTime.now(),
    //   sentBy: '2',
    //   status: MessageStatus.read,
    // ),
  ];
}
